 docsearch({
      apiKey: 'cb93c14bebd90678e789c946d95ea94d',
      indexName: 'bulma',
      inputSelector: '#algoliaSearch',
      debug: false // Set debug to true if you want to inspect the dropdown
    });
    